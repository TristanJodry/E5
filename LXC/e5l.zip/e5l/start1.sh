#!/bin/bash

quitter=1
chmod -R +x ../e5/ > /dev/null 2> /dev/null
chmod -R +x e5/ > /dev/null 2> /dev/null


while [[ $quitter -ne 0 ]]
do
    echo -e "Menu :\n1- Installation des paquets\n2- Décompression Ubuntu16\n3- Fichiers LXC\n4- Création conteneurs\n5- Mise en place apache,haproxy\n6- Iptables\n7- Backup\n8- Clef ssh\n0- Quitter"
    read choix1
    case $choix1 in
	1 )
	./etapes/apt.sh
	;;
	2 )
	echo "Pas de décompression e5 version light"
	;;
	3 )
	./etapes/lxcp.sh
	;;
	4 )
	./etapes/lxcct.sh
	;;
	5 )
	./etapes/web.sh
	;;
	6 )
	./etapes/iptables.sh
	;;
	7 )
	./etapes/backup.sh
	;;
	8 )
	./etapes/ssh.sh
	;;
	0 )
	figlet "Aurevoir"
	quitter=0
	;;
	* )
	echo "Erreur dans la saisie"
	;;
	esac
done
