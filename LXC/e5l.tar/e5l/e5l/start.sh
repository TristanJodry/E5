#!/bin/bash

quitter=1
chmod -R +x ../e5/
chmod -R +x e5/

echo "Démarrage"
apt install -y figlet > /dev/null 2> /dev/null
while [[ $quitter -ne 0 ]]
do
    echo -e "Menu :\n1- Scripts étape par étape\n2- Scripts avancés\n3- Automatique\n0- Quitter"
    read choix1
    case $choix1 in
	1 )
	./start1.sh
	;;
	2 )
	./start2.sh
	;;
	3)
	./scripts/auto.sh
	;;
	0 )
	figlet "Aurevoir"
	quitter=0
	;;
	* )
	echo "Erreur dans la saisie"
	;;
	esac
done
